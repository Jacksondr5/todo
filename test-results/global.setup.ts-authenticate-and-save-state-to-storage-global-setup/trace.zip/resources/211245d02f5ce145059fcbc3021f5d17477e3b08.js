(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_e69f0d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_e69f0d._.js",
  "chunks": [
    "static/chunks/49035_next_dist_compiled_react-dom_995edb._.js",
    "static/chunks/49035_next_dist_compiled_026d3b._.js",
    "static/chunks/49035_next_dist_client_d6c86c._.js",
    "static/chunks/49035_next_dist_486005._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0a._.js",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_9b0a42._.js"
  ],
  "source": "entry"
});
