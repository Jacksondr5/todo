(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_ea93ed._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_ea93ed._.js",
  "chunks": [
    "static/chunks/_5c8737._.css",
    "static/chunks/49035_next_d56e2f._.js",
    "static/chunks/10600_@trpc_server_dist_9de284._.js",
    "static/chunks/206d0_@trpc_client_dist_ac4fda._.js",
    "static/chunks/b431e_@tanstack_query-core_build_modern_2d2187._.js",
    "static/chunks/fb6c9_@trpc_react-query_dist_93b718._.js",
    "static/chunks/2771f_@clerk_shared_dist_e67dac._.js",
    "static/chunks/18f3c_swr_dist_aff6fe._.js",
    "static/chunks/5a10a_@clerk_clerk-react_dist_c5e38e._.js",
    "static/chunks/node_modules__pnpm_d72fcb._.js",
    "static/chunks/src_073cb3._.js",
    "static/chunks/0ffdb_@clerk_nextjs_dist_esm_app-router_3604ed._.js"
  ],
  "source": "dynamic"
});
